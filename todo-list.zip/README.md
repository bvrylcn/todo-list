# To-Do List (Task Management) Uygulaması
Bu uygulama, kullanıcıların görevlerini ekleyip, düzenleyip ve tamamlandıklarında işaretleyebileceği basit bir "To-Do List" uygulamasıdır.

## Özellikler
- Görev ekleyebilme.
- Görevleri düzenleyebilme.
- Tamamlanan görevleri işaretleyebilme.
- Görevleri silebilme.

## Gereksinimler
Python 3.x ve Flask kurulu olmalıdır.

## Kurulum
1. Gerekli bağımlılıkları yükleyin:
   ```
   pip install -r requirements.txt
   ```

2. Uygulamayı çalıştırın:
   ```
   python src/app.py
   ```

3. Tarayıcınızda `http://127.0.0.1:5000/` adresine gidin.
