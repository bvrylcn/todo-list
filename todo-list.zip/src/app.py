from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Görev listesi (veritabanı yerine basit bir liste kullanıyoruz)
tasks = []

@app.route('/')
def index():
    return render_template('index.html', tasks=tasks)

@app.route('/add', methods=['POST'])
def add_task():
    task = request.form.get('task')
    if task:
        tasks.append({'task': task, 'done': False})
    return redirect(url_for('index'))

@app.route('/complete/<int:task_index>')
def complete_task(task_index):
    tasks[task_index]['done'] = True
    return redirect(url_for('index'))

@app.route('/delete/<int:task_index>')
def delete_task(task_index):
    tasks.pop(task_index)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
